function [x,y,z]=Ray3contour(C,S,lam,c)
   if (c <= lam)
      x=sqrt(c)*S;
      y=(sqrt(c)/sqrt(lam))*C;
   else
      t=acos(sqrt(lam/c));
      dt = (pi-2*t)/1000;
      TT = [(t:dt:pi-t),(pi+t:dt:2*pi-t)];
      SS = sin(TT);
      CC = cos(TT);
      x=sqrt(c)*SS;
      y=(sqrt(c)/sqrt(lam))*CC;
   end
   z=sqrt(1-x.^2-y.^2);
   R=find(imag(z)==0);
   x=x(R);y=y(R);z=z(R);
