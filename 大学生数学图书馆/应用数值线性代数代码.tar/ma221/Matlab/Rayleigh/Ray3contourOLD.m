function [x,y,z]=Ray3contour(C,S,lam,c)
   x=sqrt(c)*S;
   y=(sqrt(c)/sqrt(lam))*C;
   z=sqrt(1-x.^2-y.^2);
   R=find(imag(z)==0);
   x=x(R);y=y(R);z=z(R);
