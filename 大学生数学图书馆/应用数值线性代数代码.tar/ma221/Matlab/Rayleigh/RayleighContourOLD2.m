% Plots contours of Rayleigh quotient rho(u,A) on the unit sphere
% A = diag([1, lam, 0])
% Input is lam, an eigenvalue in the range (0, 1)
theta=(0:.005:2*pi);
cs=[cos(theta);sin(theta)];
hold off, clg
% c are values of rho(u,A) at contours
for c=[0  (.002:(lam-.002)/4:lam-1e-5) lam*.9 lam lam*1.1  (.998:-(.998-lam)/4:lam+1e-5)  1];
   C=cs(1,:);
   S=cs(2,:);
   [x,y,z]=Ray3contour(C,S,lam,c);
   if (c < lam)
      plot3(x,y,z,'g.')
      axis('square')
      hold on
      plot3(x,y,-z,'g.')
   elseif (c == lam)
      plot3(x,y,z,'-w')
      axis('square')
      hold on
      plot3(x,y,-z,'-w')
   else
      plot3(x,y,z,'r.')
      axis('square')
      hold on
      plot3(x,y,-z,'r.')
   end
end
xlabel('x = e_1')
ylabel('y = e_2')
zlabel('z = e_3')
grid
