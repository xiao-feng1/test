a1=[[eps/4,1];[1,1]]
a2=[[eps/4,1];[1,-1]]
[l1,u1,err1]=genp(a1);
[l2,u2,err2]=genp(a2);
pause
l1
u1
l1_times_u1 = l1*u1
a1
pause
l2
u2
l2_times_u2 = l2*u2
a2
