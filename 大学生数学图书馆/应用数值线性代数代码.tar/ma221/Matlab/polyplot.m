% Matlab code polyplot.m for Math 221, Question 1.9
% Written by James Demmel, Aug 1995
%
% Form the coefficients of a polynomial specified by its roots,
%   and repeatedly add small perturbations to the coefficients,
%   plotting the resulting perturbed roots
%
% Inputs:
%   r = vector of polynomial roots
%   e = maximum relative perturbation to make to each coefficient
%   m = number of random polynomials to generate
%
% Output:
%   Plot of perturbed roots
%
% Generate polynomial coefficients
p=poly(r);
% Set up plot
hold off, clg, 
% Generate m random polynomials
for i=1:m,
%  Add random relative perturbation of at most e to each coefficient
   p1=p.*(ones(size(p))+e*2*(rand(size(p))-.5));
%  Compute roots
   r1=roots(p1);
%  Plot roots
   plot(real(r1),imag(r1),'r.'), hold on,
end
grid
