%  Plot the diagonal entries of a matrix undergoing unshifted QR iteration
%
%  Inputs:
%    a = matrix
%    m = number of QR iterations
%
%  Outputs:
%    n curves, one for each diagonal entry of a 
%
hold off
e=diag(a);
for i=1:m,
   [q,r]=qr(a);dd=diag(sign(diag(r)));r=dd*r;q=q*dd;a=r*q; ...
   e=[e,diag(a)];
end
clg
plot(e','w'),grid
title('plot of each diagonal matrix entry during QR iteration')
