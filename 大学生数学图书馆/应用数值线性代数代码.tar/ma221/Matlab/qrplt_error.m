%  Plot the diagonal entries of a matrix undergoing unshifted QR iteration
%
%  Inputs:
%    a = matrix
%    m = number of QR iterations
%
%  Outputs:
%    n curves, one for each diagonal entry of a 
%
hold off
e=diag(a);
for i=1:m,
   [q,r]=qr(a);dd=diag(sign(diag(r)));r=dd*r;q=q*dd;a=r*q; ...
   e=[e,diag(a)];
end
clg
plot(e','w'),grid
title('plot of each diagonal matrix entry during QR iteration')
disp('pause (hit return to continue)')
pause
efinal=sort(eig(a));
[es,is]=sort(e(:,m+1));
e=e(is,:);
hold off, clg
% subplot(211)
semilogy((abs(e-efinal*ones(1,m+1)))')
v=axis;
grid
title('Errors in diagonal entries vs. iteration')
% subplot(212)
% eafinal=sort(abs(efinal));
% n=length(eafinal);
% rat = eafinal(1:n-1)./eafinal(2:n),
% rat = max([0,rat'],[rat',0]),
% [rmat,mmat]=meshgrid(rat,(0:m));
% semilogy(rmat.^mmat)
% grid
% axis(v)
% title('Predicted errors in diagonal entries vs. iteration')
