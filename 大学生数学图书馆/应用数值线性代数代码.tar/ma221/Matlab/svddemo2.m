% Demonstration of mapping of circle under a linear transformation
% using the SVD
% Input: 2-by-2 matrix a
% Output: image of unit circle under a, and principle axes
%
hold off, clg
theta=(0:2*pi/1000:2*pi);
circle=[cos(theta);sin(theta)];
ellipse=a*circle;
[u,s,v]=svd(a);
s=diag(s);
nrm=max(s);
step = 1;
for i=1:step,
  rng = ( (i-1)*1000/step+1 : min(i*1000/step,max(size(ellipse))) );
  plot(ellipse(1,rng),ellipse(2,rng),'w.');
  if i==1,
     axis(1.5*nrm*[-1,1,-1,1]);
     axis('square')
     grid
     hold on
  end
  pause(.1)
end
plot([0,s(1)*u(1,1)],[0,s(1)*u(2,1)],'b')
plot([0,s(2)*u(1,2)],[0,s(2)*u(2,2)],'r')
