% try m random LU bounds:  || |L| |U| || / || A ||
bnd = 0;
dim = 0;
for i=1:m
  n = 5*i;
  dim(i) = n;
  a = randn(n,n);
  [l,u]=lu(a);
  bnd(i) = norm( abs(l)*abs(u), 1) / norm(a, 1);
end
semilogy(dim,bnd,'x')
